# Bhausaheb_Cafe 
#Output

![Screenshot 2025-04-21 115820](https://github.com/user-attachments/assets/fd7515b6-8ec2-4e0c-86a8-4f243c349157)

![Screenshot 2025-04-21 175631](https://github.com/user-attachments/assets/88038729-99bd-455e-9aff-72d174c21b91)

![Screenshot 2025-04-21 175440](https://github.com/user-attachments/assets/f3731982-e8ec-41de-b241-73c02de5c0b5)

![Screenshot 2025-04-21 120255](https://github.com/user-attachments/assets/b11e4d2e-341d-48ad-9a37-d1ce121a3f3a)

![Screenshot 2025-04-21 120017](https://github.com/user-attachments/assets/4347f170-4ea9-4561-977e-bc12890d6e48)

![Screenshot 2025-04-21 120230](https://github.com/user-attachments/assets/fa9202ea-1ea2-4521-bae1-19e0b7ae46ed)

![Screenshot 2025-04-21 174401](https://github.com/user-attachments/assets/fad29409-347c-4adf-b6fd-1cae25e864b3)





